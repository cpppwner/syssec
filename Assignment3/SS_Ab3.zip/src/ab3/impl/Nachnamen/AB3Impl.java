package ab3.impl.Nachnamen;

import ab3.AB3;
import ab3.CertTools;
import ab3.PasswordTools;

public class AB3Impl implements AB3 {

    @Override
    public CertTools newCertToolsInstance() {
	// TODO Auto-generated method stub
	return null;
    }

    @Override
    public PasswordTools newPasswordToolsInstance() {
	// TODO Auto-generated method stub
	return null;
    }

}
