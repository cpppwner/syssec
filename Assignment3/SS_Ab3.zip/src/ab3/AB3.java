package ab3;

public interface AB3 {
    public CertTools newCertToolsInstance();

    public PasswordTools newPasswordToolsInstance();
}
