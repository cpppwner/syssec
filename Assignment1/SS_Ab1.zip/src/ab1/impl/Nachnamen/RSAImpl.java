package ab1.impl.Nachnamen;

import ab1.RSA;

public class RSAImpl implements RSA {

	@Override
	public void init(int n) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public PublicKey getPublicKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PrivateKey getPrivateKey() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] encrypt(byte[] data, boolean activateOAEP) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] decrypt(byte[] data) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] sign(byte[] message) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public byte[] verify(byte[] message, byte[] signature) {
		// TODO Auto-generated method stub
		return null;
	}




}